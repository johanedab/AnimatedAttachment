# AnimatedAttachment
Allows generic animations to move attached parts
